package com.algorithm;

import java.util.ArrayList;

public class DataManager {

    private static ArrayList destinationBoxes = new ArrayList<Box>();
    public static void addBox(Box box) {
        destinationBoxes.add(box);
    }
    
    public static Box getBox(int index){
        return (Box)destinationBoxes.get(index);
    }
    
    public static int numberOfBoxes(){
        return destinationBoxes.size();
    }
}
