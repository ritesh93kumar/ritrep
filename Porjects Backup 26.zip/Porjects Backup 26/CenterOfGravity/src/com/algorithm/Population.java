package com.algorithm;
import java.util.ArrayList;

import com.domain.*;
public class Population {

    // Holds population of data
    Data[] data;
    CenterOfGravity centerOfGravity=null;

    // Construct a population
    public Population(int populationSize, boolean initialise) {
        data = new Data[populationSize];
        // If we need to initialise a population of data do so
        if (initialise) {
            // Loop and create individuals
            for (int i = 0; i < populationSize(); i++) {
                Data newData = new Data();
                newData.generateIndividual();
                saveData(i, newData);
            }
        }
    }
    
    // Saves a tour
    public void saveData(int index, Data tour) {
        data[index] = tour;
    }
    
    // Gets a tour from population
    public Data getData(int index) {
        return data[index];
    }

    // Gets the best box in the population
    public Data getFittest() {
        Data fittest = data[0];
        // Loop through individuals to find fittest
        for (int i = 1; i < populationSize(); i++) {
            if (fittest.getFitness() <= getData(i).getFitness()) {
                fittest = getData(i);
               
            }
        }
        
        /****** calculating the fittest center of gravity ********/
        ArrayList<String[]> cog_coordinates=DataPreparation.prepareForData(fittest.toString());
		
		Double[] x=new ArrayList<Double>() {{for (String tempLongString : cog_coordinates.get(0)) add(new Double(tempLongString));}}.toArray(new Double[cog_coordinates.get(0).length]);
		Double[] y=new ArrayList<Double>() {{for (String tempLongString : cog_coordinates.get(1)) add(new Double(tempLongString));}}.toArray(new Double[cog_coordinates.get(1).length]);
		Double[] w=new ArrayList<Double>() {{for (String tempLongString : cog_coordinates.get(2)) add(new Double(tempLongString));}}.toArray(new Double[cog_coordinates.get(2).length]);
		
		centerOfGravity=new CenterOfGravity();
		CenterOfGravity.theCenterOfgravity=centerOfGravity.getCenterOfGravity(x, y, w);
        return fittest;
    }

    // Gets population size
    public int populationSize() {
        return data.length;
    }
}