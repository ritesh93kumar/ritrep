package com.algorithm;

import java.util.ArrayList;
import java.util.Collections;

public class Data{

    
    private ArrayList data = new ArrayList<Box>();
    // Cache
    private double fitness = 0;
    private int distance = 0;
    
    // Constructs a blank data
    public Data(){
        for (int i = 0; i < DataManager.numberOfBoxes(); i++) {
            data.add(null);
        }
    }
    
    public Data(ArrayList data){
        this.data = data;
    }

    // Creates a random individual
    public void generateIndividual() {
        // Loop through all our boxes and add them to our data
        for (int boxIndex = 0; boxIndex < DataManager.numberOfBoxes(); boxIndex++) {
          setBox(boxIndex, DataManager.getBox(boxIndex));
        }
        // Randomly reorder the data
        //System.out.println("data="+data);
        Collections.shuffle(data);
    }

   
    public Box getBox(int tourPosition) {
        return (Box)data.get(tourPosition);
    }

   
    public void setBox(int tourPosition, Box city) {
        data.set(tourPosition, city);
        
        fitness = 0;
        distance = 0;
    }
    
    
    public double getFitness() {
        if (fitness == 0) {
            fitness = 1/(double)getFitData();
        }
        return fitness;
    }
    
    
    public int getFitData(){
        if (distance == 0) {
            int boxDistance = 0;
           
            for (int boxIndex=0; boxIndex < boxSize(); boxIndex++) {
               
                Box fromBox = getBox(boxIndex);
                
                Box destinationBox;
                if(boxIndex+1 < boxSize()){
                    destinationBox = getBox(boxIndex+1);
                }
                else{
                    destinationBox = getBox(0);
                }
                boxDistance += fromBox.distanceTo(destinationBox);
            }
            distance = boxDistance;
        }
        return distance;
    }

   
    public int boxSize() {
        return data.size();
    }
    
    
    public boolean containsBox(Box city){
        return data.contains(city);
    }
    
    @Override
    public String toString() {
        String geneString = "|";
        for (int i = 0; i < boxSize(); i++) {
            geneString += getBox(i)+"|";
        }
        return geneString;
    }
}