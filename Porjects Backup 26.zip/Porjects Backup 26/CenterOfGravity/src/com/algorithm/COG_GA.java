package com.algorithm;

import com.domain.CenterOfGravity;

public class COG_GA {

    public static void main(String[] args) {

        
        Box b = new Box(4, 3, 8);
        DataManager.addBox(b);
        Box b2 = new Box(3, 1, 4);
        DataManager.addBox(b2);
       
        
        // Initialize population
        Population pop = new Population(50, true);
        //System.out.println("Initial distance: " + pop.getFittest().getFitData());

        // Evolve population for 20 generations
        pop = GeneticAlgorithm.evolvePopulation(pop);
        for (int i = 0; i < 50; i++) {
        	System.out.println("Generation "+i);
            pop = GeneticAlgorithm.evolvePopulation(pop);
        }

        // Print final results
        System.out.println("Finished");
       // System.out.println("Final distance: " + pop.getFittest().getDistance());
        
        System.out.println("Fittest :"+pop.getFittest());
        System.out.println("Solution:"+CenterOfGravity.theCenterOfgravity);
    }
}