package com.algorithm;

public class GeneticAlgorithm {

    /* GA parameters */
    private static final double mutationRate = 0.015;
    private static final int tournamentSize = 5;
    private static final boolean elitism = true;

    // Evolves a population over one generation
    public static Population evolvePopulation(Population pop) {
          Population newPopulation = new Population(pop.populationSize(), false);

        // Keep our best individual if elitism is enabled
        int elitismOffset = 0;
        if (elitism) {
            newPopulation.saveData(0, pop.getFittest());
            elitismOffset = 1;
        }

        // Crossover population
        // Loop over the new population's size and create individuals from
        // Current population
        for (int i = elitismOffset; i < newPopulation.populationSize(); i++) {
            // Select parents
            Data parent1 = tournamentSelection(pop);
            Data parent2 = tournamentSelection(pop);
            // Crossover parents
            Data child = crossover(parent1, parent2);
            // Add child to new population
            newPopulation.saveData(i, child);
        }

        // Mutate the new population a bit to add some new genetic material
        for (int i = elitismOffset; i < newPopulation.populationSize(); i++) {
            mutate(newPopulation.getData(i));
        }

        return newPopulation;
    }

    // Applies crossover to a set of parents and creates offspring
    public static Data crossover(Data parent1, Data parent2) {
        // Create new child tour
        Data child = new Data();

        // Get start and end sub tour positions for parent1's tour
        int startPos = (int) (Math.random() * parent1.boxSize());
        int endPos = (int) (Math.random() * parent1.boxSize());

        // Loop and add the sub tour from parent1 to our child
        for (int i = 0; i < child.boxSize(); i++) {
            // If our start position is less than the end position
            if (startPos < endPos && i > startPos && i < endPos) {
                child.setBox(i, parent1.getBox(i));
            } // If our start position is larger
            else if (startPos > endPos) {
                if (!(i < startPos && i > endPos)) {
                    child.setBox(i, parent1.getBox(i));
                }
            }
        }

        // Loop through parent2's city tour
        for (int i = 0; i < parent2.boxSize(); i++) {
            // If child doesn't have the box add it
            if (!child.containsBox(parent2.getBox(i))) {
                // Loop to find a spare position in the box
                for (int ii = 0; ii < child.boxSize(); ii++) {
                   
                    if (child.getBox(ii) == null) {
                        child.setBox(ii, parent2.getBox(i));
                        break;
                    }
                }
            }
        }
        return child;
    }

    // Mutate a tour using swap mutation
    private static void mutate(Data tour) {
        // Loop through tour cities
        for(int boxPos1=0; boxPos1 < tour.boxSize(); boxPos1++){
            // Apply mutation rate
            if(Math.random() < mutationRate){
                // Get a second random position in the tour
                int boxPos2 = (int) (tour.boxSize() * Math.random());

                // Get the Boxes at target position in tour
                Box box1 = tour.getBox(boxPos1);
                Box box2 = tour.getBox(boxPos2);

                // Swap them around
                tour.setBox(boxPos2, box1);
                tour.setBox(boxPos1, box2);
            }
        }
    }

    // Selects candidate tour for crossover
    private static Data tournamentSelection(Population pop) {
        // Create a tournament population
        Population tournament = new Population(tournamentSize, false);
        // For each place in the tournament get a random candidate tour and
        // add it
        for (int i = 0; i < tournamentSize; i++) {
            int randomId = (int) (Math.random() * pop.populationSize());
            tournament.saveData(i, pop.getData(randomId));
        }
        // Get the fittest tour
        Data fittest = tournament.getFittest();
        return fittest;
    }
}