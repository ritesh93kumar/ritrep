package com.gui;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import javax.swing.JOptionPane;

import com.algorithm.Box;
import com.algorithm.DataManager;
import com.algorithm.GeneticAlgorithm;
import com.algorithm.Population;
import com.domain.CenterOfGravity;

import jssc.SerialPort;
import jssc.SerialPortEvent;
import jssc.SerialPortEventListener;
import jssc.SerialPortException;

public class SerialPortMain implements SerialPortEventListener {
	MainPage cog;
	static SerialPort port;
	String ch = "";
	int[] buff = new int[6];
	public static int i = 0;
	public static ArrayList al = new ArrayList();
	public static ArrayList al2 = new ArrayList();
	public static HashSet<String> hs=new HashSet<String>();
	
	String temp="";
	

	public SerialPortMain(String selectport, MainPage cog) {
		port = new SerialPort(selectport);
		this.cog=cog;
		try {
			open();
			if (port.isOpened()) {
				int mask = SerialPort.MASK_RXCHAR + SerialPort.MASK_TXEMPTY;
				port.setEventsMask(mask);
				port.addEventListener(this);
				port.writeBytes("A$BaC4D1E2".getBytes());
				// System.out.println("write in port");
			}
		} catch (SerialPortException se) {
			// se.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error in opening Thread...!!",
					"Error Message", JOptionPane.ERROR_MESSAGE);
			// System.out.println(se);
		}
	}

	public static void setProperties(int brate, int dbit, int sbit, int par)
			throws SerialPortException {
		port.setParams(brate, dbit, sbit, par);
	}

	public static void open() throws SerialPortException {
		if (!port.isOpened()) {
			port.openPort();
			// port.setParams(baudRate, dataBits, stopBits, parity);
			port.setParams(9600, 8, 1, 0);
		}
	}

	public static void close() throws SerialPortException {
		if (port.isOpened()) {
			port.closePort();
		}
	}

	public void serialEvent(SerialPortEvent e) {
		if (e.isRXCHAR()) {
			try {
				int[] b = port.readIntArray();

				if (b != null) {
					for (int a = 0; a < b.length; a++) {
						int a1 = b[a];
						al.add(a1-48);
					}
				}
				

				int frst = (int) al.get(0);
				if (al.size() == 3) {
					
					al2.add(al.get(1));
					al2.add(al.get(2));
					if(!equalLists(al, al2)){
						//System.out.println("data..." + al);
						String x = "0", y = "0", w = "0";
							/************* get values by position ***************/
							x = "" + al.get(1);
							y = "" + al.get(2);
							
							String orgnl_crdnt=x+", "+y;

							/************* logic to display on to gui *******************/
							Box box = new Box(Integer.parseInt(x), Integer.parseInt(y), 8);
							DataManager.addBox(box);
							
							
							hs.add(box.toString());
					        String cog_crdnt=CenterOfGravity.theCenterOfgravity;
					        System.out.println("box="+hs+ "=====cog="+cog_crdnt);
					        
					        /***********graw hashmap onto the gui*************/
					        cog.lblData.setText(""+hs);
					        
					        System.out.println("finish");
					}
					al.clear();
				} else if (al.size() > 3) {
					al.clear();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
				JOptionPane.showMessageDialog(null,
						"Plz. Exit the Application & start again...!!",
						"Error Message", JOptionPane.ERROR_MESSAGE);
				System.out.println(ex);
			}
		}

	}

	/*private void drawOnGUI(MainPage mp, String cog_crdnt, String orgnl_crdnt) {
		System.out.println(cog_crdnt+"==="+orgnl_crdnt);
		if(cog_crdnt.equals("1, 1"))
			mp.panel_11.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("1, 2"))
			mp.panel_12.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("1, 3"))
			mp.panel_13.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("1, 4"))
			mp.panel_14.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("2, 1"))
			mp.panel_21.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("2, 2"))
			mp.panel_22.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("2, 3"))
			mp.panel_23.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("2, 4"))
			mp.panel_24.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("3, 1"))
			mp.panel_31.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("3, 2"))
			mp.panel_32.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("3, 3"))
			mp.panel_33.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("3, 4"))
			mp.panel_34.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("4, 1"))
			mp.panel_41.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("4, 2"))
			mp.panel_42.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("4, 3"))
			mp.panel_43.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("4, 4"))
			mp.panel_44.setBackground(new Color(0, 128, 0));
		
		if(orgnl_crdnt.equals("1, 1"))
			mp.panel_11.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("1, 2"))
			mp.panel_12.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("1, 3"))
			mp.panel_13.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("1, 4"))
			mp.panel_14.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("2, 1"))
			mp.panel_21.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("2, 2"))
			mp.panel_22.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("2, 3"))
			mp.panel_23.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("2, 4"))
			mp.panel_24.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("3, 1"))
			mp.panel_31.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("3, 2"))
			mp.panel_32.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("3, 3"))
			mp.panel_33.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("3, 4"))
			mp.panel_34.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("4, 1"))
			mp.panel_41.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("4, 2"))
			mp.panel_42.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("4, 3"))
			mp.panel_43.setBackground(new Color(255, 0, 0));
		if(orgnl_crdnt.equals("4, 4"))
			mp.panel_44.setBackground(new Color(255, 0, 0));
		
		
	}
*/
	private int getPosition(ArrayList al2, Object element) {
		if (al2.contains(element))
			return al2.indexOf(element);
		else
			return -1;

	}
	
	public  static boolean equalLists(List<String> one, List<String> two){     
	    if (one == null && two == null){
	        return true;
	    }

	    if((one == null && two != null) 
	      || one != null && two == null
	      || one.size() != two.size()){
	        return false;
	    }

	    //to avoid messing the order of the lists we will use a copy
	    //as noted in comments by A. R. S.
	    one = new ArrayList<String>(one); 
	    two = new ArrayList<String>(two);   

	    Collections.sort(one);
	    Collections.sort(two);      
	    return one.equals(two);
	}

}
