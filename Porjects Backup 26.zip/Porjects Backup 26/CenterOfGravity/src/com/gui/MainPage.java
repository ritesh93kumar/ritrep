package com.gui;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.border.BevelBorder;

import com.test.TestCenterOfGravity;
import com.test.TestDataPreparation;

import jssc.SerialPortException;
import jssc.SerialPortList;

import java.awt.Toolkit;
import java.awt.Color;

public class MainPage extends JFrame implements ActionListener {
	JLabel plist;
	MainHeaderPanel hpanel;
	JButton setting, close;
	JComboBox jcb;
	String selectport = "";
	String[] portlist; 
	/* dialog box */
	JLabel lbr, ldb, lsb, lpr;
	JComboBox br, db, sb, pr;
	JButton set;
	int brate = 0, dbit = 0, sbit = 0, par = 8;
	//JLabel cel, humi, lprs;
	Font font = new Font("Times New Roman", Font.BOLD, 12);
	private JPanel panel;
	public static JPanel panel_11;
	public static JPanel panel_12;
	public static JPanel panel_13;
	public static JPanel panel_14;
	
	public static JPanel panel_21;
	public static JPanel panel_22;
	public static JPanel panel_23;
	public static JPanel panel_24;
	private JLabel label;
	public static JPanel panel_31;
	public static JPanel panel_32;
	public static JPanel panel_33;
	public static JPanel panel_34;
	private JLabel label_1;
	public static JPanel panel_41;
	public static JPanel panel_42;
	public static JPanel panel_43;
	public static JPanel panel_44;
	private JLabel label_2;
	private JButton btnProcess;
	public static JLabel lblData;

	public MainPage() {
		getContentPane().setBackground(new Color(0, 128, 128));
		setIconImage(Toolkit.getDefaultToolkit().getImage("icon/globe.png"));
		setTitle("");
		getContentPane().setLayout(null);
		hpanel = new MainHeaderPanel("Center of Gravity");
		hpanel.setBackground(new Color(192, 192, 192));
		hpanel.setFont(font);
		getContentPane().add(hpanel);
		hpanel.setBounds(20, 20, 450, 50);

		plist = new JLabel("Result : __, __");
		// plist.setFont(font);
		getContentPane().add(plist);
		portlist = SerialPortList.getPortNames();
		if(portlist.length != 0)
		System.out.println("PORT VALUES "+portlist[0]);
		jcb = new JComboBox();
		jcb.setFont(font);
		for (String s : portlist) {
			jcb.addItem(s);
			// System.out.println("sssssss"+s);
		}
		getContentPane().add(jcb);

		setting = new JButton("Settings");
		// setting.setFont(font);
		getContentPane().add(setting);
		close = new JButton("Close");
		close.setFont(font);
		getContentPane().add(close);
		close.setEnabled(false);
		close.addActionListener(this);
		plist.setBounds(50, 110, 130, 25);
		jcb.setBounds(170, 110, 80, 25);
		setting.setBounds(260, 110, 90, 25);
		close.setBounds(360, 110, 80, 25);
		jcb.addActionListener(this);
		setting.addActionListener(this);
		setting.setEnabled(false);
		String degree = "\u00b0";

		/*cel = new JLabel("");
		cel.setFont(font);
		getContentPane().add(cel);

		cel.setBounds(310, 180, 50, 25);*/
		
		panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(79, 180, 334, 279);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		panel_11 = new JPanel();
		panel_11.setBackground(new Color(0, 0, 0));
		panel_11.setBounds(20, 22, 65, 51);
		panel.add(panel_11);
		
		panel_12 = new JPanel();
		panel_12.setBackground(new Color(0, 0, 0));
		panel_12.setBounds(95, 22, 65, 51);
		panel.add(panel_12);
		
		panel_13 = new JPanel();
		panel_13.setBackground(new Color(0, 0, 0));
		panel_13.setBounds(168, 22, 65, 51);
		panel.add(panel_13);
		
		panel_14 = new JPanel();
		panel_14.setBackground(new Color(0, 0, 0));
		panel_14.setBounds(243, 22, 65, 51);
		panel.add(panel_14);
		/*humi = new JLabel("");
		panel_14.add(humi);
		humi.setFont(font);*/
		
		panel_21 = new JPanel();
		panel_21.setBackground(Color.BLACK);
		panel_21.setBounds(20, 83, 65, 51);
		panel.add(panel_21);
		
		panel_22 = new JPanel();
		panel_22.setBackground(Color.BLACK);
		panel_22.setBounds(95, 83, 65, 51);
		panel.add(panel_22);
		
		panel_23 = new JPanel();
		panel_23.setBackground(Color.BLACK);
		panel_23.setBounds(168, 83, 65, 51);
		panel.add(panel_23);
		
		panel_24 = new JPanel();
		panel_24.setBackground(Color.BLACK);
		panel_24.setBounds(243, 83, 65, 51);
		panel.add(panel_24);
		
		label = new JLabel("");
		label.setFont(new Font("Times New Roman", Font.BOLD, 12));
		panel_24.add(label);
		
		panel_31 = new JPanel();
		panel_31.setBackground(Color.BLACK);
		panel_31.setBounds(20, 145, 65, 51);
		panel.add(panel_31);
		
		panel_32 = new JPanel();
		panel_32.setBackground(Color.BLACK);
		panel_32.setBounds(95, 145, 65, 51);
		panel.add(panel_32);
		
		panel_33 = new JPanel();
		panel_33.setBackground(Color.BLACK);
		panel_33.setBounds(168, 145, 65, 51);
		panel.add(panel_33);
		
		panel_34 = new JPanel();
		panel_34.setBackground(Color.BLACK);
		panel_34.setBounds(243, 145, 65, 51);
		panel.add(panel_34);
		
		label_1 = new JLabel("");
		label_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		panel_34.add(label_1);
		
		panel_41 = new JPanel();
		panel_41.setBackground(Color.BLACK);
		panel_41.setBounds(20, 207, 65, 51);
		panel.add(panel_41);
		
		panel_42 = new JPanel();
		panel_42.setBackground(Color.BLACK);
		panel_42.setBounds(95, 207, 65, 51);
		panel.add(panel_42);
		
		panel_43 = new JPanel();
		panel_43.setBackground(Color.BLACK);
		panel_43.setBounds(168, 207, 65, 51);
		panel.add(panel_43);
		
		panel_44 = new JPanel();
		panel_44.setBackground(Color.BLACK);
		panel_44.setBounds(243, 207, 65, 51);
		panel.add(panel_44);
		
		label_2 = new JLabel("");
		label_2.setFont(new Font("Times New Roman", Font.BOLD, 12));
		panel_44.add(label_2);
		
		btnProcess = new JButton("Process");
		btnProcess.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String data="";
				HashSet<String> hs=SerialPortMain.hs;
				Iterator itr=hs.iterator();
				while(itr.hasNext()){
					data+=itr.next();
				}


				String str=data.replace("||", "|");
				//System.out.println("o/p="+str);
				ArrayList<String[]> cog_coordinaes=TestDataPreparation.prepareForData(str);
				Double[] x=new ArrayList<Double>() {{for (String tempLongString : cog_coordinaes.get(0)) add(new Double(tempLongString));}}.toArray(new Double[cog_coordinaes.get(0).length]);
				Double[] y=new ArrayList<Double>() {{for (String tempLongString : cog_coordinaes.get(1)) add(new Double(tempLongString));}}.toArray(new Double[cog_coordinaes.get(1).length]);
				Double[] w=new ArrayList<Double>() {{for (String tempLongString : cog_coordinaes.get(2)) add(new Double(tempLongString));}}.toArray(new Double[cog_coordinaes.get(2).length]);
				TestCenterOfGravity cog=new TestCenterOfGravity();
				
				String cog_crdnt=cog.getCenterOfGravity(x, y, w);
				System.out.println("o/p="+cog_crdnt);
				plist.setText("Result : "+cog_crdnt);
				drawOnGUI( cog_crdnt, x, y);
			}
		});
		btnProcess.setBounds(351, 146, 89, 23);
		getContentPane().add(btnProcess);
		
		lblData = new JLabel("");
		lblData.setBounds(35, 146, 306, 23);
		getContentPane().add(lblData);
		

	}
	
	private void drawOnGUI(String cog_crdnt, Double[] x, Double[] y) {
		
		if(cog_crdnt.equals("1, 1"))
			this.panel_11.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("1, 2"))
			this.panel_12.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("1, 3"))
			this.panel_13.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("1, 4"))
			this.panel_14.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("2, 1"))
			this.panel_21.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("2, 2"))
			this.panel_22.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("2, 3"))
			this.panel_23.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("2, 4"))
			this.panel_24.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("3, 1"))
			this.panel_31.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("3, 2"))
			this.panel_32.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("3, 3"))
			this.panel_33.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("3, 4"))
			this.panel_34.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("4, 1"))
			this.panel_41.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("4, 2"))
			this.panel_42.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("4, 3"))
			this.panel_43.setBackground(new Color(0, 128, 0));
		if(cog_crdnt.equals("4, 4"))
			this.panel_44.setBackground(new Color(0, 128, 0));
		
		if(x.length==1 && y.length==1){
			String crdnt=x[0].intValue()+", "+y[0].intValue();
			if(x[0].intValue()==1 && y[0].intValue()==1 && !cog_crdnt.equals(crdnt))
				this.panel_11.setBackground(new Color(0, 206, 209));
			if(x[0].intValue()==1 && y[0].intValue()==2 && !cog_crdnt.equals(crdnt))
				this.panel_12.setBackground(new Color(0, 206, 209));
			if(x[0].intValue()==1 && y[0].intValue()==3 && !cog_crdnt.equals(crdnt))
				this.panel_13.setBackground(new Color(0, 206, 209));
			if(x[0].intValue()==1 && y[0].intValue()==4 && !cog_crdnt.equals(crdnt))
				this.panel_14.setBackground(new Color(0, 206, 209));
			
			if(x[0].intValue()==2 && y[0].intValue()==1 && !cog_crdnt.equals(crdnt))
				this.panel_21.setBackground(new Color(0, 206, 209));
			if(x[0].intValue()==2 && y[0].intValue()==2 && !cog_crdnt.equals(crdnt))
				this.panel_22.setBackground(new Color(0, 206, 209));
			if(x[0].intValue()==2 && y[0].intValue()==3 && !cog_crdnt.equals(crdnt))
				this.panel_23.setBackground(new Color(0, 206, 209));
			if(x[0].intValue()==2 && y[0].intValue()==4 && !cog_crdnt.equals(crdnt))
				this.panel_24.setBackground(new Color(0, 206, 209));
			
			if(x[0].intValue()==3 && y[0].intValue()==1 && !cog_crdnt.equals(crdnt))
				this.panel_31.setBackground(new Color(0, 206, 209));
			if(x[0].intValue()==3 && y[0].intValue()==2 && !cog_crdnt.equals(crdnt))
				this.panel_32.setBackground(new Color(0, 206, 209));
			if(x[0].intValue()==3 && y[0].intValue()==3 && !cog_crdnt.equals(crdnt))
				this.panel_33.setBackground(new Color(0, 206, 209));
			if(x[0].intValue()==3 && y[0].intValue()==4 && !cog_crdnt.equals(crdnt))
				this.panel_34.setBackground(new Color(0, 206, 209));
			
			if(x[0].intValue()==4 && y[0].intValue()==1 && !cog_crdnt.equals(crdnt))
				this.panel_41.setBackground(new Color(0, 206, 209));
			if(x[0].intValue()==4 && y[0].intValue()==2 && !cog_crdnt.equals(crdnt))
				this.panel_42.setBackground(new Color(0, 206, 209));
			if(x[0].intValue()==4 && y[0].intValue()==3 && !cog_crdnt.equals(crdnt))
				this.panel_43.setBackground(new Color(0, 206, 209));
			if(x[0].intValue()==4 && y[0].intValue()==4 && !cog_crdnt.equals(crdnt))
				this.panel_44.setBackground(new Color(0, 206, 209));
			
		}else if(x.length>1 && y.length>1){
			for(int j=0; j<x.length && j<y.length; j++){
				
				String crdnt=x[j].intValue()+", "+y[j].intValue();
				
				if(x[j].intValue()==1 && y[j].intValue()==1 && !cog_crdnt.equals(crdnt))
					this.panel_11.setBackground(new Color(0, 206, 209));
				if(x[j].intValue()==1 && y[j].intValue()==2 && !cog_crdnt.equals(crdnt))
					this.panel_12.setBackground(new Color(0, 206, 209));
				if(x[j].intValue()==1 && y[j].intValue()==3 && !cog_crdnt.equals(crdnt))
					this.panel_13.setBackground(new Color(0, 206, 209));
				if(x[j].intValue()==1 && y[j].intValue()==4)
					this.panel_14.setBackground(new Color(0, 206, 209));
				
				if(x[j].intValue()==2 && y[j].intValue()==1 && !cog_crdnt.equals(crdnt))
					this.panel_21.setBackground(new Color(0, 206, 209));
				if(x[j].intValue()==2 && y[j].intValue()==2 && !cog_crdnt.equals(crdnt))
					this.panel_22.setBackground(new Color(0, 206, 209));
				if(x[j].intValue()==2 && y[j].intValue()==3 && !cog_crdnt.equals(crdnt))
					this.panel_23.setBackground(new Color(0, 206, 209));
				if(x[j].intValue()==2 && y[j].intValue()==4 && !cog_crdnt.equals(crdnt))
					this.panel_24.setBackground(new Color(0, 206, 209));
				
				if(x[j].intValue()==3 && y[j].intValue()==1 && !cog_crdnt.equals(crdnt))
					this.panel_31.setBackground(new Color(0, 206, 209));
				if(x[j].intValue()==3 && y[j].intValue()==2 && !cog_crdnt.equals(crdnt))
					this.panel_32.setBackground(new Color(0, 206, 209));
				if(x[j].intValue()==3 && y[j].intValue()==3 && !cog_crdnt.equals(crdnt))
					this.panel_33.setBackground(new Color(0, 206, 209));
				if(x[j].intValue()==3 && y[j].intValue()==4 && !cog_crdnt.equals(crdnt))
					this.panel_34.setBackground(new Color(0, 206, 209));
				
				if(x[j].intValue()==4 && y[j].intValue()==1 && !cog_crdnt.equals(crdnt))
					this.panel_41.setBackground(new Color(0, 206, 209));
				if(x[j].intValue()==4 && y[j].intValue()==2 && !cog_crdnt.equals(crdnt))
					this.panel_42.setBackground(new Color(0, 206, 209));
				if(x[j].intValue()==4 && y[j].intValue()==3 && !cog_crdnt.equals(crdnt))
					this.panel_43.setBackground(new Color(0, 206, 209));
				if(x[j].intValue()==4 && y[j].intValue()==4 && !cog_crdnt.equals(crdnt))
					this.panel_44.setBackground(new Color(0, 206, 209));
			}
		}
		
	}

	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == jcb) {
			selectport = (String) jcb.getSelectedItem();

			jcb.setEnabled(false);
			close.setEnabled(true);
			setting.setEnabled(true);
			SerialPortMain sm = new SerialPortMain(selectport, this);

		} else if (ae.getSource() == close) {
			jcb.setEnabled(true);
			close.setEnabled(false);
			setting.setEnabled(false);
			try {
				SerialPortMain.close();
			} catch (SerialPortException ex) {
				// ex.printStackTrace();
				JOptionPane.showMessageDialog(this,
						"Error in closing Thread...!!", "Error Message",
						JOptionPane.ERROR_MESSAGE);
				System.out.println(ex);
			}

		} else if (ae.getSource() == setting) {
			PortDialog pd = new PortDialog(this, true);
			pd.setTitle("Serial Port Settings");
			pd.setSize(300, 300);
			pd.setResizable(false);
			pd.setLocation(550, 100);
			pd.setVisible(true);
		}

	}

	class PortDialog extends JDialog implements ActionListener {
		Font font = new Font("Times New Roman", Font.BOLD, 12);

		public PortDialog(MainPage s, boolean m) {
			super(s, m);
			setLayout(null);
			lbr = new JLabel("Baud Rate  : ");
			lbr.setFont(font);
			add(lbr);
			br = new JComboBox();
			br.setFont(font);
			add(br);
			ldb = new JLabel("Data Bits  : ");
			ldb.setFont(font);
			add(ldb);
			db = new JComboBox();
			db.setFont(font);
			add(db);
			lsb = new JLabel("Stop Bits  : ");
			lsb.setFont(font);
			add(lsb);
			sb = new JComboBox();
			add(sb);
			lpr = new JLabel("Parity   : ");
			add(lpr);
			pr = new JComboBox();
			add(pr);
			for (int i = 0; i < 5; i++) {
				pr.addItem(i);
				System.out.println("1111111" + i);
			}
			for (int i = 1; i < 4; i++) {
				sb.addItem(i);
				System.out.println("22222" + i);
			}
			for (int i = 8; i > 5; i--) {
				db.addItem(i);
				System.out.println("33333" + i);
			}

			br.addItem(9600);
			br.addItem(4800);
			br.addItem(14400);
			br.addItem(19200);
			br.addItem(38400);
			br.addItem(57600);
			br.addItem(115200);
			br.addItem(128000);
			br.addItem(256000);

			lbr.setBounds(70, 20, 70, 25);
			br.setBounds(150, 20, 80, 25);
			ldb.setBounds(70, 60, 70, 25);
			db.setBounds(150, 60, 80, 25);
			lsb.setBounds(70, 100, 70, 25);
			sb.setBounds(150, 100, 80, 25);
			lpr.setBounds(70, 140, 70, 25);
			pr.setBounds(150, 140, 80, 25);

			set = new JButton("Set Properties");
			add(set);
			set.setBounds(100, 200, 130, 25);
			set.addActionListener(this);
			br.addActionListener(this);
			db.addActionListener(this);
			sb.addActionListener(this);
			pr.addActionListener(this);
		}

		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == set && brate != 0 && dbit != 0 && sbit != 0
					&& par != 8) {
				try {
					SerialPortMain.setProperties(brate, dbit, sbit, par);
				} catch (SerialPortException ex) {
					ex.printStackTrace();
				}
				JOptionPane.showMessageDialog(null,
						"Settings Updated Successfully..!!");
				this.dispose();
			} else if (e.getSource() == br) {
				brate = (int) br.getSelectedItem();
				System.out.println("brate" + brate);
			} else if (e.getSource() == db) {
				dbit = (int) db.getSelectedItem();
				System.out.println("dbit" + dbit);
			} else if (e.getSource() == sb) {
				sbit = (int) sb.getSelectedItem();
			} else if (e.getSource() == pr) {
				par = (int) pr.getSelectedItem();
			} else {
				JOptionPane.showMessageDialog(null,
						"Select all the settings first...!!!",
						"Warning Message", JOptionPane.WARNING_MESSAGE);
			}
		}
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				MainPage wms = new MainPage();
				wms.setTitle("Smart Public Transportation");
				wms.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				wms.setLocation(450, 50);
				wms.setResizable(false);
				wms.setSize(500, 520);
				wms.getContentPane().setLayout(null);
				wms.setVisible(true);
			}
		});
	}
}

class MainHeaderPanel extends JPanel {

	JLabel l;

	public MainHeaderPanel(String title) {
		l = new JLabel(title);
		add(l);
		l.setFont(new Font("Times New Roman", Font.BOLD, 25));
		setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
	}
}

