package com.test;
import java.text.DecimalFormat;

import com.algorithm.Box;


public class A {
	static Box b=null;
	public static void main(String[] args) {
		/*double number = 3.6666666666666666666;
		DecimalFormat numberFormat = new DecimalFormat("#.00");
		System.out.println(numberFormat.format(number));
		
		//double finalValue = Math.round( number * 100.0 ) / 100.0;
		// System.out.println(finalValue);
		String finalVal=numberFormat.format(number);
		//System.out.println(finalVal.substring(finalVal.indexOf(".")+1));
		String num=finalVal.substring(0,finalVal.indexOf("."));
		System.out.println("num="+num);
		double dgt=Double.parseDouble(finalVal.substring(finalVal.indexOf(".")+1));
		if(dgt<=50)
			System.out.println(number);
		else
			System.out.println(number+1);*/
		
		System.out.println(b==null);
		b=new Box(4, 6, 6);
		System.out.println(b==null);
		System.out.println(b);
	}

}
