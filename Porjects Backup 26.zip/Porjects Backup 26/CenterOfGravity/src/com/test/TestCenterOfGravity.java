package com.test;

import java.text.DecimalFormat;

public class TestCenterOfGravity {

	static double Xc = 0, Yc = 0;
	static DecimalFormat numberFormat = new DecimalFormat("#.00");

	// private double cog1=0;
	public static void main(String[] args) {
		Double[] Xi = { (double) 4, (double) 3 };
		Double[] Yi = { (double) 3, (double) 1 };
		Double[] Wi = { (double) 8, (double) 4 };
		
		System.out.println("Center of Graviy="+new TestCenterOfGravity().getCenterOfGravity(Xi, Yi, Wi));
	}
	
	public String getCenterOfGravity(Double[] Xi, Double[] Yi, Double[] Wi) {

		System.out.println("SumOf_Wi=" + sum_Wi(Wi));
		System.out.println("SumOf_XiWi=" + sum_AXISiWi(Xi, Wi));
		System.out.println("SumOf_YiWi=" + sum_AXISiWi(Yi, Wi));

		Xc = sum_AXISiWi(Xi, Wi) / sum_Wi(Wi);
		Yc = sum_AXISiWi(Yi, Wi) / sum_Wi(Wi);
 
		/*System.out.println("COG--> (" + numberFormat.format(Xc) + ", "
				+ numberFormat.format(Yc) + ");");
		System.out.println("COG--> (" + roundNumber(Xc) + ", "
				+ roundNumber(Yc) + ");");*/
		return roundNumber(Xc)+", "+roundNumber(Yc);
	}

	/***********round figure of the number**************/
	public static int roundNumber(double number) {

		String finalVal = numberFormat.format(number);
		int num = Integer
				.parseInt(finalVal.substring(0, finalVal.indexOf(".")));
		
		double dgt = Integer
				.parseInt(finalVal.substring(finalVal.indexOf(".") + 1));
		if (dgt <= 50)
			return num;
		else
			return num + 1;
	}

	/*************it returns the sum of all weight*************/
	public static double sum_Wi(Double[] wi) {
		if (wi.length != 0) {
			double sum = 0;
			if (wi.length == 1)
				return wi[0];
			else {
				for (double i : wi) {
					sum += i;
				}
			}
			return sum;
		} else
			return 0;
	}

	public static double sum_AXISiWi(Double[] xi, Double[] wi) {
		if (xi.length != 0 && wi.length != 0) {
			double productOf = 0;
			if (xi.length == 1 && wi.length == 1)
				return wi[0];
			else {
				for (int i = 0; i < xi.length && i < xi.length; i++) {
					productOf += (xi[i] * wi[i]);
				}
			}
			return productOf;
		} else
			return 0;
	}
	
}
