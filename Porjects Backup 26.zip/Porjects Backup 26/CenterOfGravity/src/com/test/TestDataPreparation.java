package com.test;

import java.util.ArrayList;


public class TestDataPreparation {

	public static String x="", y="", w="";
	
	public static void main(String[] args) {
		//String str="|8, 1, 3|6, 2, 12|4, 8, 5|8, 2, 8|";
		String str="|1, 2, 8|1, 1, 8|2, 1, 8|2, 4, 8|";
		ArrayList<String[]> cog_coordinaes=prepareForData(str);
		
		Double[] x=new ArrayList<Double>() {{for (String tempLongString : cog_coordinaes.get(0)) add(new Double(tempLongString));}}.toArray(new Double[cog_coordinaes.get(0).length]);
		Double[] y=new ArrayList<Double>() {{for (String tempLongString : cog_coordinaes.get(1)) add(new Double(tempLongString));}}.toArray(new Double[cog_coordinaes.get(1).length]);
		Double[] w=new ArrayList<Double>() {{for (String tempLongString : cog_coordinaes.get(2)) add(new Double(tempLongString));}}.toArray(new Double[cog_coordinaes.get(2).length]);
		
		TestCenterOfGravity cog=new TestCenterOfGravity();
		System.out.println("Answer="+cog.getCenterOfGravity(x, y, w));
	}
	
	//seperate the values from sring=|8, 1, 3|6, 2, 12|4, 8, 5|8, 2, 8| and reurn the araylist
	public static ArrayList<String[]> prepareForData(String str) {
		System.out.println(str);
		String []s1=str.split(",");
		int i=0;
		for(String s:s1){
			//System.out.println(s);
			if(s.contains("|")){
				if(!(s.substring(s.indexOf("|")+1)).equals("")){
					if(x.equals("")){
						x=s.substring(s.indexOf("|")+1);
					}else{
						x+=","+s.substring(s.indexOf("|")+1);
					}
				}
				if(!(s.substring(0, s.indexOf("|")+1)).equals("")){
					if(i==0)
						continue;
					else{
						if(w.equals("")){
							w=s.substring(1, s.indexOf("|"));
						}else{
							w+=","+s.substring(1, s.indexOf("|"));
						}
					}
				}
			}else{
				if(y.equals("")){
					y=s;
				}else{
					y+=","+s;
				}
			}
			i++;
		}
		
		ArrayList<String[]> al=new ArrayList<String[]>();
		al.add(x.split(","));
		al.add(y.split(","));
		al.add(w.split(","));
		return al;
	}

}
