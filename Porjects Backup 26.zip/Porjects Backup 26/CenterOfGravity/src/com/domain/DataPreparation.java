package com.domain;
import java.util.ArrayList;


public class DataPreparation {
	public static String coordinates=null;

	public static String x="", y="", w="";
	
	public static ArrayList<String[]> prepareForData(String str) {
		System.out.println(str);
		coordinates=str;
		String []s1=str.split(",");
		int i=0;
		for(String s:s1){
			//System.out.println(s);
			if(s.contains("|")){
				if(!(s.substring(s.indexOf("|")+1)).equals("")){
					if(x.equals("")){
						x=s.substring(s.indexOf("|")+1);
					}else{
						x+=","+s.substring(s.indexOf("|")+1);
					}
				}
				if(!(s.substring(0, s.indexOf("|")+1)).equals("")){
					if(i==0)
						continue;
					else{
						if(w.equals("")){
							w=s.substring(1, s.indexOf("|"));
						}else{
							w+=","+s.substring(1, s.indexOf("|"));
						}
					}
				}
			}else{
				if(y.equals("")){
					y=s;
				}else{
					y+=","+s;
				}
			}
			i++;
		}
		
		ArrayList<String[]> al=new ArrayList<String[]>();
		al.add(x.split(","));
		al.add(y.split(","));
		al.add(w.split(","));
		return al;
	}

}
