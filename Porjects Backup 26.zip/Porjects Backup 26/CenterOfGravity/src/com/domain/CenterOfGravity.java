 package com.domain;
import java.text.DecimalFormat;

public class CenterOfGravity {

	static double Xc = 0, Yc = 0;
	static DecimalFormat numberFormat = new DecimalFormat("#.00");
	public static String theCenterOfgravity=null;

	public String getCenterOfGravity(Double[] Xi, Double[] Yi, Double[] Wi) {

		Xc = sum_AXISiWi(Xi, Wi) / sum_Wi(Wi);
		Yc = sum_AXISiWi(Yi, Wi) / sum_Wi(Wi);
 
		return roundNumber(Xc)+", "+roundNumber(Yc);
	}

	public static int roundNumber(double number) {

		String finalVal = numberFormat.format(number);
		int num = Integer
				.parseInt(finalVal.substring(0, finalVal.indexOf(".")));
		
		double dgt = Integer
				.parseInt(finalVal.substring(finalVal.indexOf(".") + 1));
		if (dgt <= 50)
			return num;
		else
			return num + 1;
	}

	public static double sum_Wi(Double[] wi) {
		if (wi.length != 0) {
			double sum = 0;
			if (wi.length == 1)
				return wi[0];
			else {
				for (double i : wi) {
					sum += i;
				}
			}
			return sum;
		} else
			return 0;
	}

	public static double sum_AXISiWi(Double[] xi, Double[] wi) {
		if (xi.length != 0 && wi.length != 0) {
			double productOf = 0;
			if (xi.length == 1 && wi.length == 1)
				return wi[0];
			else {
				for (int i = 0; i < xi.length && i < xi.length; i++) {
					productOf += (xi[i] * wi[i]);
				}
			}
			return productOf;
		} else
			return 0;
	}
	
}
