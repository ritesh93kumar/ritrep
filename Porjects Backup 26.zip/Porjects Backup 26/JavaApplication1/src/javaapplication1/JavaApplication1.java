package javaapplication1;

import java.util.*;
import javaapplication1.WeightData;
import jdk.nashorn.internal.ir.JumpStatement;

/**
 *
 * @author Sandeeep Singh
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        List<WeightData> weightDatalist;
        int[][] all_cordinates = new int[16][16];
        int[] all_weight = new int[16];
        int fweight,fxcordi,fycordi,weight;
        String isWeight;
        weightDatalist = new ArrayList<>();
        WeightData weightData = new WeightData();
       
        Scanner reader = new Scanner(System.in);
        System.out.println("Enter first weght first x cordi and y cordinate");
        fweight = reader.nextInt();
        fxcordi = reader.nextInt();
        fycordi = reader.nextInt();
        
        weightData.setCordiX(fxcordi);
        weightData.setCordiY(fycordi);
        weightData.setWeight(fweight);
        weightDatalist.add(weightData);
        
        System.out.println("Enter data as "+fweight+" FX "+fxcordi+" FY "+fycordi);
        
        R: 
        System.out.println("Enter next weight ");
        weight = reader.nextInt();
        
        for (int x =1 ;x<5;x++){
            for(int y=1;y<5;y++){
                if(weightDatalist.size() != 0){
                    
              	for (int i=0;i<weightDatalist.size();i++){
                    
                    if(weightDatalist.get(i).getCordiX() != x && weightDatalist.get(i).getCordiY() != y){
                        
                        float xvalues = getXVaalue(weight,x,weightDatalist);
                        float yvalues = getYVaalue(weight, y, weightDatalist);
                        System.out.println("The X calculated vaues "+xvalues +" AND y value is as follow as "+yvalues+" X Cordinates "+x+" and Y cordinates "+y);
                
                        if (xvalues == yvalues){
                            System.out.println("COG Found at the cordinates as "+x+" And "+y);
                            
                             WeightData weightData1 = new WeightData();
                             weightData1.setCordiX(x);
                             weightData1.setCordiY(y);
                             weightData1.setWeight(weight);
                             weightDatalist.add(weightData1);
                             
                            System.out.println("Do you wnat to enter next weight ? y / n");
                            String isnext = reader.nextLine(); 
                  
                           if (isnext.equals("y")){
                               
                           }else{
                               break;
                           }
                        }
                    }
                }
               }
            }
            System.out.println(" ");
        }
    }
    
    public static float getXVaalue(int weight, int xcord, List<WeightData> weightDatasList){
        int sum_weight = 0;
        int sum_multi = 0;
        if(weightDatasList.size() != 0){
            for(int i =0;i<weightDatasList.size();i++){
                WeightData  data = weightDatasList.get(i);
                if(data.getCordiX() == xcord){
                    sum_weight =+ data.getWeight();
                    sum_multi =+ (data.getCordiX()* data.getWeight());
                }
            }
            System.out.println("Toal weight x: "+sum_weight+" and weight : "+weight+" SUM MULTI "+sum_multi+" OTHER "+(xcord*weight)+" LIST size "+weightDatasList.size());
            sum_weight = sum_weight + weight;
            sum_multi = sum_multi+ (xcord*weight);
            return (sum_multi/sum_weight);
        }
        return 0;
    }
    
    private static float getYVaalue(int weight, int ycord,List<WeightData> weightDatasList){
        
        int sum_weight = 0;
        int sum_multi = 0;
        if(weightDatasList.size() != 0){
            for(int i =0;i<weightDatasList.size();i++){
                if(ycord != weightDatasList.get(i).getCordiY()){
                    WeightData  data = weightDatasList.get(i);
                    sum_weight =+ data.getWeight();
                    sum_multi =+ (data.getCordiY()* data.getWeight());
                }
            }
            sum_weight = sum_weight + weight;
            sum_multi = sum_multi+ (ycord*weight);
            return (sum_multi/sum_weight);
        }
        return 0;
    }
    
    
}
