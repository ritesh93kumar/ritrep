/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author Sandeeep Singh
 */
public class WeightData {
    public int weight;
    public int cordi_x;
    public int cordi_y;
    
    public int getWeight(){
        return weight;
    }
    
    public void setWeight(int weight){
        this.weight = weight;
    }
    
    public int getCordiX(){
        return cordi_x;
    }
    
    public void setCordiX(int cordix){
        this.cordi_x = cordix;
    }
    
    public int getCordiY(){
        return cordi_y;
    }
    
    public void setCordiY(int cordiy){
        this.cordi_y = cordiy;
    }
    
}
